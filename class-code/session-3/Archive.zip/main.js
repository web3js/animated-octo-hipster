var app = (function(w, d) {

	return {

	};

})(window, document);


